﻿drop table authorities CASCADE ;
drop table academic_records CASCADE ;
drop table applications CASCADE ;
drop table degrees CASCADE ;
drop table additional_info CASCADE ;
drop table additional_field_values CASCADE ;
drop table users CASCADE ;
drop table grad_progs CASCADE ;
drop table dept CASCADE ;
drop table status CASCADE ;

drop sequence hibernate_sequence CASCADE ;